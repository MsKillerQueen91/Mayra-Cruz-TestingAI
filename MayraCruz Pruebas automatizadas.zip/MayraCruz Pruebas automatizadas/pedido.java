import java.util.List;

public class Pedido {
    private int id;
    private int usuarioId;
    private List<Producto> productos;
    private String estado;

    public Pedido(int id, int usuarioId, List<Producto> productos, String estado) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.productos = productos;
        this.estado = estado;
    }

    public boolean confirmarPedido() {
        this.estado = "Confirmado";
        return true;
    }

    public String rastrearPedido() {
        return estado;
    }

    public void actualizarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
    }

    public String getEstado() {
        return estado;
    }
}