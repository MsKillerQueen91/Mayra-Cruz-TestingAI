public class Producto {
    private int id;
    private String nombre;
    private String descripcion;
    private double precio;
    private int stock;

    public Producto(int id, String nombre, String descripcion, double precio, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.stock = stock;
    }

    public Producto buscarProducto(String criterio) {
        // Código para buscar productos
        return null;
    }

    public void actualizarStock(int cantidad) {
        this.stock = cantidad;
    }

    public String obtenerDetalles() {
        return descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public int getStock() {
        return stock;
    }
}