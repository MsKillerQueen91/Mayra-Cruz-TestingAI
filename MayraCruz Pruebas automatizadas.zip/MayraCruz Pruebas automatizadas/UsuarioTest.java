import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class UsuarioTest {
    private Usuario usuario;

    @Before
    public void setUp() {
        usuario = new Usuario(1, "Juan", "juan@example.com", "password123");
    }

    @Test
    public void testRegistrar() {
        assertTrue(usuario.registrar());
    }

    @Test
    public void testIniciarSesion() {
        assertTrue(usuario.iniciarSesion("juan@example.com", "password123"));
    }

    @Test
    public void testActualizarPerfil() {
        usuario.actualizarPerfil("Juan Perez", "juan.perez@example.com", "newpassword123");
        assertEquals("Juan Perez", usuario.getNombre());
        assertEquals("juan.perez@example.com", usuario.getCorreoElectronico());
    }
}