import java.util.ArrayList;
import java.util.List;

public class Carrito {
    private int usuarioId;
    private List<Producto> productos;

    public Carrito(int usuarioId) {
        this.usuarioId = usuarioId;
        this.productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto, int cantidad) {
        productos.add(producto);
    }

    public void modificarCantidad(int productoId, int cantidad) {
        for (Producto prod : productos) {
            if (prod.getId() == productoId) {
                // Código para modificar la cantidad de productos en el carrito
            }
        }
    }

    public void eliminarProducto(int productoId) {
        productos.removeIf(prod -> prod.getId() == productoId);
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public int getCantidad(int productoId) {
        for (Producto prod : productos) {
            if (prod.getId() == productoId) {
                return prod.getStock();
            }
        }
        return 0;
    }
}