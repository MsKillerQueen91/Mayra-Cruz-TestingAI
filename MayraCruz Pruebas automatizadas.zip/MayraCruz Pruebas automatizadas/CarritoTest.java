import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class CarritoTest {
    private Carrito carrito;
    private Producto producto;

    @Before
    public void setUp() {
        carrito = new Carrito(1);
        producto = new Producto(1, "Martillo", "Martillo de acero", 100.0, 50);
    }

    @Test
    public void testAgregarProducto() {
        carrito.agregarProducto(producto, 2);
        assertEquals(1, carrito.getProductos().size());
    }

    @Test
    public void testModificarCantidad() {
        carrito.agregarProducto(producto, 2);
        carrito.modificarCantidad(producto.getId(), 5);
        assertEquals(5, carrito.getCantidad(producto.getId()));
    }

    @Test
    public void testEliminarProducto() {
        carrito.agregarProducto(producto, 2);
        carrito.eliminarProducto(producto.getId());
        assertEquals(0, carrito.getProductos().size());
    }
}