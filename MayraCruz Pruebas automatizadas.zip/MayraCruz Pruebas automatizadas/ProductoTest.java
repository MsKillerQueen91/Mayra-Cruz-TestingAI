import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ProductoTest {
    private Producto producto;

    @Before
    public void setUp() {
        producto = new Producto(1, "Martillo", "Martillo de acero", 100.0, 50);
    }

    @Test
    public void testBuscarProducto() {
        Producto resultado = producto.buscarProducto("Martillo");
        assertNotNull(resultado);
        assertEquals("Martillo", resultado.getNombre());
    }

    @Test
    public void testActualizarStock() {
        producto.actualizarStock(30);
        assertEquals(30, producto.getStock());
    }

    @Test
    public void testObtenerDetalles() {
        String detalles = producto.obtenerDetalles();
        assertEquals("Martillo de acero", detalles);
    }
}