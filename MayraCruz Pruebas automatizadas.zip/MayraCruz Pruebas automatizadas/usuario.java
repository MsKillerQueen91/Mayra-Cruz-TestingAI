public class Usuario {
    private int id;
    private String nombre;
    private String correoElectronico;
    private String contrasena;

    public Usuario(int id, String nombre, String correoElectronico, String contrasena) {
        this.id = id;
        this.nombre = nombre;
        this.correoElectronico = correoElectronico;
        this.contrasena = contrasena;
    }

    public boolean registrar() {
        // Código para registrar al usuario
        return true;
    }

    public boolean iniciarSesion(String correoElectronico, String contrasena) {
        // Código para iniciar sesión
        return this.correoElectronico.equals(correoElectronico) && this.contrasena.equals(contrasena);
    }

    public void actualizarPerfil(String nombre, String correoElectronico, String contrasena) {
        this.nombre = nombre;
        this.correoElectronico = correoElectronico;
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }
}