import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

public class PedidoTest {
    private Pedido pedido;
    private Producto producto;

    @Before
    public void setUp() {
        producto = new Producto(1, "Martillo", "Martillo de acero", 100.0, 50);
        List<Producto> productos = new ArrayList<>();
        productos.add(producto);
        pedido = new Pedido(1, 1, productos, "Pendiente");
    }

    @Test
    public void testConfirmarPedido() {
        assertTrue(pedido.confirmarPedido());
    }

    @Test
    public void testRastrearPedido() {
        String estado = pedido.rastrearPedido();
        assertEquals("Pendiente", estado);
    }

    @Test
    public void testActualizarEstado() {
        pedido.actualizarEstado("Enviado");
        assertEquals("Enviado", pedido.getEstado());
    }
}